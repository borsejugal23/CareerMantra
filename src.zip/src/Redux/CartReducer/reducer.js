const initialstate={
    
}
export const reducer=(state=initialstate,{type,payload})=>{
    switch(type){
      default: return state
    }
}