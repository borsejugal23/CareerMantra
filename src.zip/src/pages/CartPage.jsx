import React from 'react'

const CartPage = () => {
    
  return (
    <div>
        <h1>Cart</h1>
    </div>
  )
}

export default CartPage